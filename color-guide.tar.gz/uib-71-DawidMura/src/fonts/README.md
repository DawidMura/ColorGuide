# The `fonts` folder

Put any custom downloaded font files here, and import the to your css / scss files
